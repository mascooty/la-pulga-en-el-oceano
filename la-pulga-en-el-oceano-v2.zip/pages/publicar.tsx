export default function Publicar() {
  return (
    <main style={{ padding: "2rem" }}>
      <h1>Publicar tu pulga 🐜</h1>
      <form style={{ display: "flex", flexDirection: "column", gap: "1rem", maxWidth: "400px" }}>
        <input type="text" placeholder="Título de la pulga" required />
        <textarea placeholder="Descripción" required />
        <input type="number" placeholder="Precio por noche (€)" required />
        <button type="submit">Publicar</button>
      </form>
    </main>
  );
}