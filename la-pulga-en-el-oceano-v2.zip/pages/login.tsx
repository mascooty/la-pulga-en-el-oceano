export default function Login() {
  return (
    <main style={{ padding: "2rem", textAlign: "center" }}>
      <h1>Iniciar sesión</h1>
      <p>(Simulación de login)</p>
      <button>Entrar con correo</button>
    </main>
  );
}