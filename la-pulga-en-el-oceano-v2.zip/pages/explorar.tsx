import Link from 'next/link';

const pulgas = [
  { id: 1, nombre: "La pulga de Lili", descripcion: "Apartamento con vistas al mar" },
  { id: 2, nombre: "La pulga de Paco", descripcion: "Casa rural entre montañas" },
  { id: 3, nombre: "La pulga de Aisha", descripcion: "Loft urbano con estilo" },
];

export default function Explorar() {
  return (
    <main style={{ padding: "2rem" }}>
      <h1>Explorar Pulgas 🐜</h1>
      <ul>
        {pulgas.map((pulga) => (
          <li key={pulga.id} style={{ marginBottom: "1rem" }}>
            <Link href={`/pulga/${pulga.id}`}>
              <strong>{pulga.nombre}</strong>
              <p>{pulga.descripcion}</p>
            </Link>
          </li>
        ))}
      </ul>
    </main>
  );
}