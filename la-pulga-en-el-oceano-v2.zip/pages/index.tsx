import Link from 'next/link';

export default function Home() {
  return (
    <main style={{ padding: "2rem", textAlign: "center" }}>
      <h1>🐜 La Pulga en el Océano 🌊</h1>
      <p>Encuentra y publica pulgas (alquileres) fácilmente.</p>
      <Link href="/explorar"><button style={{ marginTop: "1rem", padding: "1rem 2rem" }}>Explorar pulgas</button></Link>
    </main>
  );
}