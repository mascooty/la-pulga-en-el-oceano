import { useRouter } from 'next/router';

export default function Pulga() {
  const router = useRouter();
  const { id } = router.query;

  return (
    <main style={{ padding: "2rem" }}>
      <h1>Detalles de la pulga #{id}</h1>
      <p>Esta es una página de ejemplo para mostrar detalles de la pulga seleccionada.</p>
    </main>
  );
}