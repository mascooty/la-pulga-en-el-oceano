export default function Custom404() {
  return (
    <div style={{ padding: "2rem", textAlign: "center" }}>
      <h1>🐜 Pulga perdida</h1>
      <p>No hemos encontrado la página. Tal vez se fue nadando 🌊</p>
    </div>
  );
}